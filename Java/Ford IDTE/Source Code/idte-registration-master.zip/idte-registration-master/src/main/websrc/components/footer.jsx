import React from 'react';

class Footer extends React.Component {
  render() {
    return (
      <div className='footer'>
        <p>
          Ford IDTE 2019-2020 <a href='/idte/admin/admin.html'>Admin</a>
        </p>
      </div>
    );
  }
}

export default Footer;
